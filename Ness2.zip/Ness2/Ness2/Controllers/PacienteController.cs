﻿using Ness2.Models;
using Ness2.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Ness2.Controllers
{
    public class PacienteController : Controller
    {
        private PacienteRepository respository = new PacienteRepository();
        // GET: Paciente
        public ActionResult Index()
        {
            return View(respository.GetAll());
        }

        // GET: Paciente/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Paciente/Create
        [HttpPost]
        public ActionResult Create(Paciente paciente)
        {
            if (ModelState.IsValid)
            {
                respository.Save(paciente);
                return RedirectToAction("Index");
            }
            else
            {
                return View(paciente);
            }
        }

        // GET: Paciente/Edit/5
        public ActionResult Edit(int id, DateTime data)
        {
            var paciente = respository.GetById(id);
           // var data = (from dat in Paciente where dat.data == Data).FirstOrDefault();
            

            if (paciente == null)
            {
                return HttpNotFound();
            }
        //    if (data = false)
          //  {
            //    return HttpNotFound();
            //}

            return View(paciente);
        }

        // POST: Paciente/Edit/5
        [HttpPost]
        public ActionResult Edit(Paciente paciente)
        {
            if (ModelState.IsValid)
            {
                respository.Update(paciente);
                return RedirectToAction("Index");
            }
            else
            {
                return View(paciente);
            }
        }

        // POST: Paciente/Delete/5
        [HttpPost]
        public ActionResult Delete(int id)
        {
            respository.DeleteById(id);
            return Json(respository.GetAll());
        }
    }
}
