﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Ness2.Models
{
    public class Paciente
    {
        [Display(Name = "Id do Paciente")]
        public int Id { get; set; }

        [Required(ErrorMessage = "Campo 'Nome' é obrigatório")]
        

        [Required(ErrorMessage = "Campo 'Sobrenome' é obrigatório")]
        public string Sobrenome { get; set; }

        [Required(ErrorMessage = "Campo 'Cidade' obrigatório")]
        public string Cidade { get; set; }

        [Required(ErrorMessage = "Campo 'Endereço' é obrigatório")]
        [Display(Name = "Endereço")]
        public string Endereco { get; set; }

        [Required(ErrorMessage = "Campo 'E-mail' é obrigatório")]
        [Display(Name = "E-mail")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Campo 'Convênio' é obrigatório")]
        [Display(Name = "Convênio")]
        public string Convenio { get; set; }

        public DateTime Data { get; set; }

        public string Status { get; set; }

    }
}
