﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Ness2.Models
{
    public class Consulta
    {
        [Display(Name = "Id do Paciente")]
        public int IdPaciente { get; set; }

        
        public string Nome { get; set; }

        public string Sobrenome { get; set; }

        public string Cidade { get; set; }

       
    }
}