﻿using Ness2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Ness2.Repository;
using System.Data.SqlClient;
using System.Data;

namespace Ness2.Repository
{
    public class PacienteRepository : AbstractRepository<Paciente, int>
    {
        ///<summary>Exclui uma Paciente pela entidade
        ///<param name="entity">Referência de Paciente que será excluída.</param>
        ///</summary>
        public override void Delete(Paciente entity)
        {
            using (var conn = new SqlConnection(StringConnection))
            {
                string sql = "DELETE Paciente Where Id=@Id";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@Id", entity.Id);
                try
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
                catch (Exception e)
                {
                    throw e;
                }
            }
        }

        ///<summary>Exclui uma Paciente pelo ID
        ///<param name="id">Id do registro que será excluído.</param>
        ///</summary>
        public override void DeleteById(int id)
        {
            using (var conn = new SqlConnection(StringConnection))
            {
                string sql = "DELETE Paciente Where Id=@Id";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@Id", id);
                try
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
                catch (Exception e)
                {
                    throw e;
                }
            }
        }

        ///<summary>Obtém todas as Pacientes
        ///<returns>Retorna as Pacientes cadastradas.</returns>
        ///</summary>
        public override List<Paciente> GetAll()
        {
            string sql = "Select Id, Nome, Sobrenome, Cidade, Endereco, Email, Convenio, Status  FROM Paciente ORDER BY Nome";
            using (var conn = new SqlConnection(StringConnection))
            {
                var cmd = new SqlCommand(sql, conn);
                List<Paciente> list = new List<Paciente>();
                Paciente p = null;
                try
                {
                    conn.Open();
                    using (var reader = cmd.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        while (reader.Read())
                        {
                            p = new Paciente();
                            p.Id = (int)reader["Id"];
                            p.Nome = reader["Nome"].ToString();
                            p.Sobrenome = reader["Sobrenome"].ToString();
                            p.Cidade = reader["Cidade"].ToString();
                            p.Endereco = reader["Endereco"].ToString();
                            p.Email = reader["Email"].ToString();
                            p.Convenio = reader["Convenio"].ToString();
                            p.Status = reader["Status"].ToString();
                            list.Add(p);
                        }
                    }
                }
                catch (Exception e)
                {
                    throw e;
                }
                return list;
            }
        }

        ///<summary>Obtém uma Paciente pelo ID
        ///<param name="id">Id do registro que obtido.</param>
        ///<returns>Retorna uma referência de Paciente do registro encontrado ou null se ele não for encontrado.</returns>
        ///</summary>
        public override Paciente GetById(int id)
        {
            using (var conn = new SqlConnection(StringConnection))
            {
                string sql = "Select Id, Nome, Sobrenome, Cidade, Endereco, Email, Convenio, Status   FROM Paciente WHERE Id=@Id";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@Id", id);
                Paciente p = null;
                try
                {
                    conn.Open();
                    using (var reader = cmd.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        if (reader.HasRows)
                        {
                            if (reader.Read())
                            {
                                p = new Paciente();
                                p.Id = (int)reader["Id"];
                                p.Nome = reader["Nome"].ToString();
                                p.Sobrenome = reader["Sobrenome"].ToString();
                                p.Cidade = reader["Cidade"].ToString();
                                p.Endereco = reader["Endereco"].ToString();
                                p.Email = reader["Email"].ToString();
                                p.Convenio = reader["Convenio"].ToString();
                                p.Status = reader["Status"].ToString();
                            }
                        }
                    }
                }
                catch (Exception e)
                {
                    throw e;
                }
                return p;
            }
        }

        ///<summary>Salva a Paciente no banco
        ///<param name="entity">Referência de Paciente que será salva.</param>
        ///</summary>
        public override void Save(Paciente entity)
        {
            using (var conn = new SqlConnection(StringConnection))
            {
                string sql = "INSERT INTO Paciente (Nome, Sobrenome, Cidade, Endereco, Email, Convenio) VALUES (@Nome, @Sobrenome, @Cidade, @Endereco, @Email, @Convenio)";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@Nome", entity.Nome);
                cmd.Parameters.AddWithValue("@Sobrenome", entity.Sobrenome);
                cmd.Parameters.AddWithValue("@Cidade", entity.Cidade);
                cmd.Parameters.AddWithValue("@Endereco", entity.Endereco);
                cmd.Parameters.AddWithValue("@Email", entity.Email);
                cmd.Parameters.AddWithValue("@Convenio", entity.Convenio);
                try
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
                catch (Exception e)
                {
                    throw e;
                }
            }
        }

        ///<summary>Atualiza a Paciente no banco
        ///<param name="entity">Referência de Paciente que será atualizada.</param>
        ///</summary>
        public override void Update(Paciente entity)
        {
            using (var conn = new SqlConnection(StringConnection))
            {
                string sql = "UPDATE Paciente SET Nome=@Nome, Sobrenome=@Sobrenome, Cidade=@Cidade, Endereco=@Endereco, Email=@Email, Convenio=@Convenio, Data=@Data, Status=@Status  Where Id=@Id";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@Id", entity.Id);
                cmd.Parameters.AddWithValue("@Nome", entity.Nome);
                cmd.Parameters.AddWithValue("@Sobrenome", entity.Sobrenome);
                cmd.Parameters.AddWithValue("@Cidade", entity.Cidade);
                cmd.Parameters.AddWithValue("@Endereco", entity.Endereco);
                cmd.Parameters.AddWithValue("@Email", entity.Email);
                cmd.Parameters.AddWithValue("@Convenio", entity.Convenio);
                cmd.Parameters.AddWithValue("@Data", entity.Data);
                cmd.Parameters.AddWithValue("@Status", entity.Status);
                try
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
                catch (Exception e)
                {
                    throw e;
                }
            }
        }
    }
}